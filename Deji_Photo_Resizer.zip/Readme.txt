DejiResizer App

This is a simple app that resizes images in a selected folder to a specified width and height.
Installation

    Download the executable file from [link to executable file].
    Double-click the executable file to run the app.



Compatibility

This app is compatible with Windows
Usage

    Open the app by double-clicking the executable file.
    Enter 1 to start or 2 to end the program.
    Select the folder containing the images you want to resize.
    Enter the desired width and height for the images.
    The resized images will be saved in the same folder.

Note: The app will automatically exit after 5 attempts or when the user inputs 2.



Contact

If you have any questions or would like to report any issues, please feel free to contact the developer, Obaude Ayodeji, at Smilingdej@gmail.com.

You can also check out my YouTube channel for more tutorials and projects: Dynamic Technocrat
https://www.youtube.com/@dynamictechnocrat